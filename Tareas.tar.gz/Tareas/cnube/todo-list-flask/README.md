# todo-list-flask
Proyecto de Flask demostrativo para IDGS
